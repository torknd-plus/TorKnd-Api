# Task

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**user_id** | **int** |  | [optional] 
**type_task_id** | **int** |  | [optional] 
**date_create** | [**\DateTime**](\DateTime.md) |  | [optional] 
**json_parameters** | **string** |  | [optional] 
**date_start** | [**\DateTime**](\DateTime.md) |  | [optional] 
**date_end** | [**\DateTime**](\DateTime.md) |  | [optional] 
**json_resul** | **string** |  | [optional] 
**is_error_result** | **bool** |  | [optional] 
**is_good_result** | **bool** |  | [optional] 
**task_guid** | **string** |  | [optional] 
**error_message** | **string** |  | [optional] 
**error_stack** | **string** |  | [optional] 
**type_task** | [**\Swagger\Client\Model\TypeTask**](TypeTask.md) |  | [optional] 
**user** | [**\Swagger\Client\Model\User**](User.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

