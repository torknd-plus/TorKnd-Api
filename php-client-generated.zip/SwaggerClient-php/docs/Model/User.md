# User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**user_login** | **string** |  | [optional] 
**user_password** | **string** |  | [optional] 
**user_guid** | **string** |  | [optional] 
**date_create** | [**\DateTime**](\DateTime.md) |  | [optional] 
**name_company** | **string** |  | [optional] 
**tasks** | [**\Swagger\Client\Model\Task[]**](Task.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

