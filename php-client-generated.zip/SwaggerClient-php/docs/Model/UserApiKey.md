# UserApiKey

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**email** | **string** |  | [optional] 
**api_key** | **string** |  | [optional] 
**user_secrets** | [**\Swagger\Client\Model\UserSecret[]**](UserSecret.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

