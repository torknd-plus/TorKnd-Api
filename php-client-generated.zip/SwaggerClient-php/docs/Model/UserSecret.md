# UserSecret

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**user_guid** | **string** |  | [optional] 
**login** | **string** |  | [optional] 
**password** | **string** |  | [optional] 
**user_api_key_id** | **int** |  | [optional] 
**user_api_key** | [**\Swagger\Client\Model\UserApiKey**](UserApiKey.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

