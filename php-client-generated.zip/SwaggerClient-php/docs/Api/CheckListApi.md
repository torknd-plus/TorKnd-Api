# Swagger\Client\CheckListApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiCheckListUserGuidPost**](CheckListApi.md#apichecklistuserguidpost) | **POST** /api/CheckList/{UserGuid} | 

# **apiCheckListUserGuidPost**
> \Swagger\Client\Model\Task apiCheckListUserGuidPost($user_guid, $body)



### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\CheckListApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$user_guid = "38400000-8cf0-11bd-b23e-10b96e4ef00d"; // string | 
$body = new \Swagger\Client\Model\CheckListMain(); // \Swagger\Client\Model\CheckListMain | 

try {
    $result = $apiInstance->apiCheckListUserGuidPost($user_guid, $body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CheckListApi->apiCheckListUserGuidPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_guid** | [**string**](../Model/.md)|  |
 **body** | [**\Swagger\Client\Model\CheckListMain**](../Model/CheckListMain.md)|  | [optional]

### Return type

[**\Swagger\Client\Model\Task**](../Model/Task.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/_*+json
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

