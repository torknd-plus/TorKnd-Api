# Swagger\Client\TypeTasksApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiTypeTasksGet**](TypeTasksApi.md#apitypetasksget) | **GET** /api/TypeTasks | 
[**apiTypeTasksIdGet**](TypeTasksApi.md#apitypetasksidget) | **GET** /api/TypeTasks/{id} | 

# **apiTypeTasksGet**
> \Swagger\Client\Model\TypeTask[] apiTypeTasksGet()



### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\TypeTasksApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->apiTypeTasksGet();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling TypeTasksApi->apiTypeTasksGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\TypeTask[]**](../Model/TypeTask.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **apiTypeTasksIdGet**
> \Swagger\Client\Model\TypeTask apiTypeTasksIdGet($id)



### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\TypeTasksApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$id = 789; // int | 

try {
    $result = $apiInstance->apiTypeTasksIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling TypeTasksApi->apiTypeTasksIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  |

### Return type

[**\Swagger\Client\Model\TypeTask**](../Model/TypeTask.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

