# IO.Swagger.Model.Task
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** |  | [optional] 
**UserId** | **long?** |  | [optional] 
**TypeTaskId** | **long?** |  | [optional] 
**DateCreate** | **DateTime?** |  | [optional] 
**JsonParameters** | **string** |  | [optional] 
**DateStart** | **DateTime?** |  | [optional] 
**DateEnd** | **DateTime?** |  | [optional] 
**JsonResul** | **string** |  | [optional] 
**IsErrorResult** | **bool?** |  | [optional] 
**IsGoodResult** | **bool?** |  | [optional] 
**TaskGuid** | **Guid?** |  | [optional] 
**ErrorMessage** | **string** |  | [optional] 
**ErrorStack** | **string** |  | [optional] 
**TypeTask** | [**TypeTask**](TypeTask.md) |  | [optional] 
**User** | [**User**](User.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

