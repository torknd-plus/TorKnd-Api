# IO.Swagger.Api.SubjectApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ApiSubjectUserGuidPost**](SubjectApi.md#apisubjectuserguidpost) | **POST** /api/Subject/{UserGuid} | 

<a name="apisubjectuserguidpost"></a>
# **ApiSubjectUserGuidPost**
> Task ApiSubjectUserGuidPost (Guid? userGuid, SubjectLegalEntity body)



### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApiSubjectUserGuidPostExample
    {
        public void main()
        {

            var apiInstance = new SubjectApi();
            var userGuid = new Guid?(); // Guid? | 
            var body = new SubjectLegalEntity(); // SubjectLegalEntity |  (optional) 

            try
            {
                Task result = apiInstance.ApiSubjectUserGuidPost(userGuid, body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SubjectApi.ApiSubjectUserGuidPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userGuid** | [**Guid?**](.md)|  | 
 **body** | [**SubjectLegalEntity**](SubjectLegalEntity.md)|  | [optional] 

### Return type

[**Task**](Task.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/_*+json
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

