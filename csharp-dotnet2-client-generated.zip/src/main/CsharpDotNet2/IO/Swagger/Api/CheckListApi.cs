using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface ICheckListApi
    {
        /// <summary>
        ///  
        /// </summary>
        /// <param name="userGuid"></param>
        /// <param name="body"></param>
        /// <returns>Task</returns>
        Task ApiCheckListUserGuidPost (Guid? userGuid, CheckListMain body);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class CheckListApi : ICheckListApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CheckListApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public CheckListApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="CheckListApi"/> class.
        /// </summary>
        /// <returns></returns>
        public CheckListApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        ///  
        /// </summary>
        /// <param name="userGuid"></param>
        /// <param name="body"></param>
        /// <returns>Task</returns>
        public Task ApiCheckListUserGuidPost (Guid? userGuid, CheckListMain body)
        {
            // verify the required parameter 'userGuid' is set
            if (userGuid == null) throw new ApiException(400, "Missing required parameter 'userGuid' when calling ApiCheckListUserGuidPost");
    
            var path = "/api/CheckList/{UserGuid}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "UserGuid" + "}", ApiClient.ParameterToString(userGuid));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                    postBody = ApiClient.Serialize(body); // http body (model) parameter

            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ApiCheckListUserGuidPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ApiCheckListUserGuidPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Task) ApiClient.Deserialize(response.Content, typeof(Task), response.Headers);
        }
    
    }
}
