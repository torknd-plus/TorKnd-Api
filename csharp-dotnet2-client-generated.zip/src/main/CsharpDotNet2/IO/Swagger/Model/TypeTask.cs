using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class TypeTask {
    /// <summary>
    /// Gets or Sets Id
    /// </summary>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public long? Id { get; set; }

    /// <summary>
    /// Gets or Sets NameTypeTask
    /// </summary>
    [DataMember(Name="nameTypeTask", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "nameTypeTask")]
    public string NameTypeTask { get; set; }

    /// <summary>
    /// Gets or Sets Tasks
    /// </summary>
    [DataMember(Name="tasks", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "tasks")]
    public List<Task> Tasks { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class TypeTask {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  NameTypeTask: ").Append(NameTypeTask).Append("\n");
      sb.Append("  Tasks: ").Append(Tasks).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
