using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class Task {
    /// <summary>
    /// Gets or Sets Id
    /// </summary>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public long? Id { get; set; }

    /// <summary>
    /// Gets or Sets UserId
    /// </summary>
    [DataMember(Name="userId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "userId")]
    public long? UserId { get; set; }

    /// <summary>
    /// Gets or Sets TypeTaskId
    /// </summary>
    [DataMember(Name="typeTaskId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "typeTaskId")]
    public long? TypeTaskId { get; set; }

    /// <summary>
    /// Gets or Sets DateCreate
    /// </summary>
    [DataMember(Name="dateCreate", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "dateCreate")]
    public DateTime? DateCreate { get; set; }

    /// <summary>
    /// Gets or Sets JsonParameters
    /// </summary>
    [DataMember(Name="jsonParameters", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "jsonParameters")]
    public string JsonParameters { get; set; }

    /// <summary>
    /// Gets or Sets DateStart
    /// </summary>
    [DataMember(Name="dateStart", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "dateStart")]
    public DateTime? DateStart { get; set; }

    /// <summary>
    /// Gets or Sets DateEnd
    /// </summary>
    [DataMember(Name="dateEnd", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "dateEnd")]
    public DateTime? DateEnd { get; set; }

    /// <summary>
    /// Gets or Sets JsonResul
    /// </summary>
    [DataMember(Name="jsonResul", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "jsonResul")]
    public string JsonResul { get; set; }

    /// <summary>
    /// Gets or Sets IsErrorResult
    /// </summary>
    [DataMember(Name="isErrorResult", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "isErrorResult")]
    public bool? IsErrorResult { get; set; }

    /// <summary>
    /// Gets or Sets IsGoodResult
    /// </summary>
    [DataMember(Name="isGoodResult", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "isGoodResult")]
    public bool? IsGoodResult { get; set; }

    /// <summary>
    /// Gets or Sets TaskGuid
    /// </summary>
    [DataMember(Name="taskGuid", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "taskGuid")]
    public Guid? TaskGuid { get; set; }

    /// <summary>
    /// Gets or Sets ErrorMessage
    /// </summary>
    [DataMember(Name="errorMessage", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "errorMessage")]
    public string ErrorMessage { get; set; }

    /// <summary>
    /// Gets or Sets ErrorStack
    /// </summary>
    [DataMember(Name="errorStack", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "errorStack")]
    public string ErrorStack { get; set; }

    /// <summary>
    /// Gets or Sets TypeTask
    /// </summary>
    [DataMember(Name="typeTask", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "typeTask")]
    public TypeTask TypeTask { get; set; }

    /// <summary>
    /// Gets or Sets User
    /// </summary>
    [DataMember(Name="user", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "user")]
    public User User { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Task {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  UserId: ").Append(UserId).Append("\n");
      sb.Append("  TypeTaskId: ").Append(TypeTaskId).Append("\n");
      sb.Append("  DateCreate: ").Append(DateCreate).Append("\n");
      sb.Append("  JsonParameters: ").Append(JsonParameters).Append("\n");
      sb.Append("  DateStart: ").Append(DateStart).Append("\n");
      sb.Append("  DateEnd: ").Append(DateEnd).Append("\n");
      sb.Append("  JsonResul: ").Append(JsonResul).Append("\n");
      sb.Append("  IsErrorResult: ").Append(IsErrorResult).Append("\n");
      sb.Append("  IsGoodResult: ").Append(IsGoodResult).Append("\n");
      sb.Append("  TaskGuid: ").Append(TaskGuid).Append("\n");
      sb.Append("  ErrorMessage: ").Append(ErrorMessage).Append("\n");
      sb.Append("  ErrorStack: ").Append(ErrorStack).Append("\n");
      sb.Append("  TypeTask: ").Append(TypeTask).Append("\n");
      sb.Append("  User: ").Append(User).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
