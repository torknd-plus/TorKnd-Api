using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class SubjectLegalEntity {
    /// <summary>
    /// Gets or Sets Inn
    /// </summary>
    [DataMember(Name="inn", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "inn")]
    public string Inn { get; set; }

    /// <summary>
    /// Gets or Sets Ogrn
    /// </summary>
    [DataMember(Name="ogrn", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "ogrn")]
    public string Ogrn { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class SubjectLegalEntity {\n");
      sb.Append("  Inn: ").Append(Inn).Append("\n");
      sb.Append("  Ogrn: ").Append(Ogrn).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
