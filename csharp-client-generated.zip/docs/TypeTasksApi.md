# IO.Swagger.Api.TypeTasksApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ApiTypeTasksGet**](TypeTasksApi.md#apitypetasksget) | **GET** /api/TypeTasks | 
[**ApiTypeTasksIdGet**](TypeTasksApi.md#apitypetasksidget) | **GET** /api/TypeTasks/{id} | 

<a name="apitypetasksget"></a>
# **ApiTypeTasksGet**
> List<TypeTask> ApiTypeTasksGet ()



### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApiTypeTasksGetExample
    {
        public void main()
        {
            var apiInstance = new TypeTasksApi();

            try
            {
                List&lt;TypeTask&gt; result = apiInstance.ApiTypeTasksGet();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TypeTasksApi.ApiTypeTasksGet: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List<TypeTask>**](TypeTask.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="apitypetasksidget"></a>
# **ApiTypeTasksIdGet**
> TypeTask ApiTypeTasksIdGet (long? id)



### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApiTypeTasksIdGetExample
    {
        public void main()
        {
            var apiInstance = new TypeTasksApi();
            var id = 789;  // long? | 

            try
            {
                TypeTask result = apiInstance.ApiTypeTasksIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TypeTasksApi.ApiTypeTasksIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **long?**|  | 

### Return type

[**TypeTask**](TypeTask.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
