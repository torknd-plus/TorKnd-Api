# IO.Swagger.Model.User
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** |  | [optional] 
**UserLogin** | **string** |  | [optional] 
**UserPassword** | **string** |  | [optional] 
**UserGuid** | **Guid?** |  | [optional] 
**DateCreate** | **DateTime?** |  | [optional] 
**NameCompany** | **string** |  | [optional] 
**Tasks** | [**List&lt;Task&gt;**](Task.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

