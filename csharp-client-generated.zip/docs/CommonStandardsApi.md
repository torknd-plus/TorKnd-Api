# IO.Swagger.Api.CommonStandardsApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ApiCommonStandardsUserGuidGet**](CommonStandardsApi.md#apicommonstandardsuserguidget) | **GET** /api/CommonStandards/{UserGuid} | 

<a name="apicommonstandardsuserguidget"></a>
# **ApiCommonStandardsUserGuidGet**
> Task ApiCommonStandardsUserGuidGet (Guid? userGuid)



### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApiCommonStandardsUserGuidGetExample
    {
        public void main()
        {
            var apiInstance = new CommonStandardsApi();
            var userGuid = new Guid?(); // Guid? | 

            try
            {
                Task result = apiInstance.ApiCommonStandardsUserGuidGet(userGuid);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CommonStandardsApi.ApiCommonStandardsUserGuidGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userGuid** | [**Guid?**](Guid?.md)|  | 

### Return type

[**Task**](Task.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
