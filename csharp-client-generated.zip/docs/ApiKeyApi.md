# IO.Swagger.Api.ApiKeyApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ApiApiKeyEmailGet**](ApiKeyApi.md#apiapikeyemailget) | **GET** /api/ApiKey/{Email} | 

<a name="apiapikeyemailget"></a>
# **ApiApiKeyEmailGet**
> UserApiKey ApiApiKeyEmailGet (string email)



### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApiApiKeyEmailGetExample
    {
        public void main()
        {
            var apiInstance = new ApiKeyApi();
            var email = email_example;  // string | 

            try
            {
                UserApiKey result = apiInstance.ApiApiKeyEmailGet(email);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ApiKeyApi.ApiApiKeyEmailGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **email** | **string**|  | 

### Return type

[**UserApiKey**](UserApiKey.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
