# IO.Swagger.Api.UserApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ApiUserLoginPasswordNameCompanyApiKeyGet**](UserApi.md#apiuserloginpasswordnamecompanyapikeyget) | **GET** /api/User/{Login}/{Password}/{NameCompany}/{ApiKey} | 

<a name="apiuserloginpasswordnamecompanyapikeyget"></a>
# **ApiUserLoginPasswordNameCompanyApiKeyGet**
> User ApiUserLoginPasswordNameCompanyApiKeyGet (string login, string password, string nameCompany, Guid? apiKey)



### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApiUserLoginPasswordNameCompanyApiKeyGetExample
    {
        public void main()
        {
            var apiInstance = new UserApi();
            var login = login_example;  // string | 
            var password = password_example;  // string | 
            var nameCompany = nameCompany_example;  // string | 
            var apiKey = new Guid?(); // Guid? | 

            try
            {
                User result = apiInstance.ApiUserLoginPasswordNameCompanyApiKeyGet(login, password, nameCompany, apiKey);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling UserApi.ApiUserLoginPasswordNameCompanyApiKeyGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **login** | **string**|  | 
 **password** | **string**|  | 
 **nameCompany** | **string**|  | 
 **apiKey** | [**Guid?**](Guid?.md)|  | 

### Return type

[**User**](User.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
